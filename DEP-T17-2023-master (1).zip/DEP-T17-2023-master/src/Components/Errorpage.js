import React from "react"
import {
    BrowserRouter as Router,
    Route,
    Link,
    Routes,
    useHistory,
} from "react-router-dom"
import {
    Row,
    Col,
    Container,
    Button,
    Form,
    FormGroup,
    Navbar,
} from "react-bootstrap"
import "bootstrap/dist/css/bootstrap.min.css"
function Errorpage() {
    return (
        <div>
            <div>page doesn't exist</div>
        </div>
    )
}

export default Errorpage
